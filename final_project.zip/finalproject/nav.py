#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import numpy as np

class MazeSolver:
    def __init__(self):
        rospy.init_node('maze_solver')
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback)
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.odom_callback)
        
        self.maze_size = (10, 10)  # Example grid size
        self.grid = np.full(self.maze_size, float('inf'))  # Flood fill grid
        self.robot_pos = (0, 0)  # Current position in grid coordinates
        self.goal = (9, 9)  # Example goal position
        self.grid[self.goal] = 0  # Initialize goal
        
        self.update_flood_fill()
    
    def update_flood_fill(self):
        queue = [self.goal]
        while queue:
            x, y = queue.pop(0)
            current_value = self.grid[x, y]
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.maze_size[0] and 0 <= ny < self.maze_size[1]:
                    if self.grid[nx, ny] > current_value + 1:
                        self.grid[nx, ny] = current_value + 1
                        queue.append((nx, ny))
    
    def scan_callback(self, data):
        # Process LaserScan data to update walls in the grid
        pass  # To be implemented based on sensor specifics
    
    def odom_callback(self, data):
        # Update robot position based on odometry
        pass  # To be implemented based on odometry specifics
    
    def move_to_next_cell(self):
        x, y = self.robot_pos
        next_pos = None
        min_value = float('inf')
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.maze_size[0] and 0 <= ny < self.maze_size[1]:
                if self.grid[nx, ny] < min_value:
                    min_value = self.grid[nx, ny]
                    next_pos = (nx, ny)
        if next_pos:
            self.move_to_cell(next_pos)
    
    def move_to_cell(self, target):
        # Implement movement logic to the target cell
        vel_msg = Twist()
        # Example: Move forward or turn based on direction
        self.cmd_vel_pub.publish(vel_msg)
    
    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.move_to_next_cell()
            rate.sleep()

if __name__ == '__main__':
    solver = MazeSolver()
    solver.run()
