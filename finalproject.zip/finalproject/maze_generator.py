import os

def generate_maze_world(file_path="maze.world"):
    # Maze parameters
    wall_width = 0.2
    wall_height = 2.0
    maze_size = 5  # Define maze grid size

    # Start writing the SDF XML content
    sdf_content = """<?xml version="1.0" ?>
<sdf version="1.6">
  <world name="default">
    <include>
      <uri>model://sun</uri>
    </include>
    <include>
      <uri>model://ground_plane</uri>
    </include>
    <physics type="ode">
      <real_time_update_rate>1000</real_time_update_rate>
    </physics>
"""

    # Maze layout as a simple grid of walls
    for i in range(maze_size):
        for j in range(maze_size):
            if i % 2 == 0 or j % 2 == 0:  # Set walls on even rows and columns
                wall_name = f"wall_{i}_{j}"
                x = i
                y = j
                sdf_content += f"""
    <model name="{wall_name}">
      <static>true</static>
      <link name="link">
        <collision name="collision">
          <geometry>
            <box>
              <size>{wall_width} {wall_width} {wall_height}</size>
            </box>
          </geometry>
        </collision>
        <visual name="visual">
          <geometry>
            <box>
              <size>{wall_width} {wall_width} {wall_height}</size>
            </box>
          </geometry>
          <material>
            <ambient>0.7 0.7 0.7 1</ambient>
            <diffuse>0.8 0.8 0.8 1</diffuse>
          </material>
        </visual>
        <pose>{x} {y} {wall_height / 2} 0 0 0</pose>
      </link>
    </model>
"""

    # Close the SDF XML content
    sdf_content += """
  </world>
</sdf>
"""

    # Write content to the world file
    with open(file_path, 'w') as f:
        f.write(sdf_content)
    print(f"Generated maze world file at {file_path}")

# Generate the maze world file
generate_maze_world()
